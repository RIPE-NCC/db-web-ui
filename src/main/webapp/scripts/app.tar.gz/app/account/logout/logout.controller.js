'use strict';

angular.module('whoisWebuiApp')
    .controller('LogoutController', function (Auth) {
        Auth.logout();
    });
