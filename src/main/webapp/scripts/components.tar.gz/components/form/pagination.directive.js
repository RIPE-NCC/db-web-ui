/* globals $ */
'use strict';

angular.module('whoisWebuiApp')
    .directive('whoisWebuiAppPagination', function() {
        return {
            templateUrl: 'scripts/components/form/pagination.html'
        };
    });
