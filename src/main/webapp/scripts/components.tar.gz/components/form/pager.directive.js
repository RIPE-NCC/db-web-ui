/* globals $ */
'use strict';

angular.module('whoisWebuiApp')
    .directive('whoisWebuiAppPager', function() {
        return {
            templateUrl: 'scripts/components/form/pager.html'
        };
    });
